const express = require("express");
const { db } = require("../connect");
const dotenv = require("dotenv");
const nodemailer = require("nodemailer");
dotenv.config();

const appointment = (req, res) => {
  const { name, phone, email, record, date, time, visit } = req.body;

  // Log the email for debugging purposes
  console.log("Email received:", email);

  // Check for required fields
  if (!name || !phone || !email || !date || !time || !visit) {
    return res.status(400).json({ error: "Missing required fields in the request." });
  }

  // Configure Nodemailer transporter
  const transporter = nodemailer.createTransport({
    host: "mail.jabalpurivfcentre.com",
    port: 465,
    secure: true,
    auth: {
      user: "support@jabalpurivfcentre.com",
      pass: "JBPivf@321",
    },
  });

  // Email to Team
  const mailOptionsTeam = {
    from: process.env.EMAILSENDER,
    to: "fertilitycenterjbp@gmail.com",
    // to: "shubhsoni1996th@gmail.com",
    subject: "New Appointment - Jabalpur IVF Center",
    text: `Dear Team,

You have received a new appointment request with the following details:

Name: ${name}
Phone: ${phone}
Email: ${email}
Record Number: ${record}
Date: ${date}
Time: ${time}
Visit Type: ${visit}

Please ensure the appointment is confirmed with the patient.

Best regards,
Jabalpur IVF Center`,
  };

  // Email to Patient
  const mailOptionsPatient = {
    from: process.env.EMAILSENDER,
    to: email, // Patient's email
    cc: "fertilitycenterjbp@gmail.com", // Optional: send a copy to the team
    subject: "Appointment Confirmation - Jabalpur IVF Center",
    text: `Dear ${name},

We are pleased to inform you that your appointment has been successfully scheduled with Jabalpur IVF Center.

Appointment Details:
Name: ${name}
Phone: ${phone}
Email: ${email}
Record Number: ${record}
Date: ${date}
Time: ${time}
Visit Type: ${visit}

If you have any questions or need to make changes, please contact us at +91-7770877117 or fertilitycenterjbp@gmail.com.

Thank you for choosing Jabalpur IVF Center.

Best regards,
Jabalpur IVF Center
+91-7770877117
https://jabalpurivfcentre.com`,
  };

  // Send email to the team
  transporter.sendMail(mailOptionsTeam, (error, info) => {
    if (error) {
      console.error("Error sending email to team:", error);
      return res.status(500).send("An error occurred while sending the email to the team.");
    }
    console.log("Email sent to the team:", info.response);

    // Send email to the patient
    transporter.sendMail(mailOptionsPatient, (error, info) => {
      if (error) {
        console.error("Error sending email to patient:", error);
        return res.status(500).send("An error occurred while sending the email to the patient.");
      }
      console.log("Email sent to the patient:", info.response);

      // Save data to the database
      const insertQuery =
        "INSERT INTO appointment (patient_name, mobile_number, email_id, record_number, appointment_date, appointment_time, visit) VALUES (?, ?, ?, ?, ?, ?, ?)";
      const values = [name, phone, email, record, date, time, visit];

      db.query(insertQuery, values, (dbError, result) => {
        if (dbError) {
          console.error("Error saving data to the database:", dbError);
          return res.status(500).send("An error occurred while saving data to the database.");
        }

        console.log("Data saved to the database:", result);
        res.status(200).send("Emails sent and data saved successfully!");
      });
    });
  });
};

const booknow = (req, res) => {
  const { name, phone, date } = req.body;
  // console.log(email);

  if (!name || !phone || !date) {
    return res
      .status(400)
      .json({ error: "Missing required fields in the request." });
  }

  // Configure Nodemailer transporter
  const transporter = nodemailer.createTransport({
    host: "mail.jabalpurivfcentre.com",
    port: 465,
    secure: true,
    auth: {
      user: "support@jabalpurivfcentre.com",
      pass: "JBPivf@321",
    },
  });

  const mailOptions = {
    from: process.env.EMAILSENDER,
    to: "fertilitycenterjbp@gmail.com",
    // to: "shubhsoni1996th@gmail.com",
    subject: "New Appointment Booking - Jabalpur IVF Center",
     text: `Dear Team,
     
You have received a new appointment request with the following details:
    
Patient Name : ${name}
Mobile Number: ${phone}
Appointment Date: ${date}

Please ensure the appointment is confirmed with the patient.

Best regards,
Jabalpur IVF Center`,
    };

  // Send the email
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error(error);
      return res.status(500).send("An error occurred while sending the email.");
    }

    console.log("Email sent:", info.response);

    // Save data to the database
    const insertQuery =
      "INSERT INTO booknow (Patient_Name, Booking_Date, Mobile_number ) VALUES (?, ?, ?)";
    const values = [name, phone, date];

    db.query(insertQuery, values, (dbError, result) => {
      if (dbError) {
        console.error("Error saving data to the database:", dbError);
        return res
          .status(500)
          .send("An error occurred while saving data to the database.");
      }

      console.log("Data saved to the database:", result);
      res.status(200).send("Email sent and data saved successfully!");
    });
  });
};

const contact = (req, res) => {
  const { name, address, email, phone, subject, message } = req.body;

  // Log the email for debugging purposes
  console.log("Email received:", email);

  // Check for required fields
  if (!name || !address || !email || !phone || !subject || !message) {
    return res.status(400).json({ error: "Missing required fields in the request." });
  }

  // Configure Nodemailer transporter
  const transporter = nodemailer.createTransport({
    host: "mail.jabalpurivfcentre.com",
    port: 465,
    secure: true,
    auth: {
      user: "support@jabalpurivfcentre.com",
      pass: "JBPivf@321",
    },
  });

  // Email to Team
  const mailOptionsTeam = {
    from: process.env.EMAILSENDER,
    to: "fertilitycenterjbp@gmail.com",
    subject: "New Contact Inquiry - Jabalpur IVF Center",
    text: `Dear Team,

You have received a new contact inquiry with the following details:

- Name: ${name}
- Address: ${address}
- Email: ${email}
- Phone: ${phone}
- Subject: ${subject}
- Message: ${message}

Please reach out to the person as soon as possible.

Best regards,
Jabalpur IVF Center`,
  };

  // Email to Patient
  const mailOptionsPatient = {
    from: process.env.EMAILSENDER,
    to: email, // Patient's email
    subject: "Your Contact Form Submission - Jabalpur IVF Center",
    text: `Dear ${name},

Thank you for reaching out to us at Jabalpur IVF Center. We have successfully received your inquiry with the following details:

- Name: ${name}
- Address: ${address}
- Email: ${email}
- Phone: ${phone}
- Subject: ${subject}
- Message: ${message}

Our team will get back to you as soon as possible.

Best regards,
Jabalpur IVF Center`,
  };

  // Send email to the team
  transporter.sendMail(mailOptionsTeam, (error, info) => {
    if (error) {
      console.error("Error sending email to team:", error);
      return res.status(500).send("An error occurred while sending the email to the team.");
    }
    console.log("Email sent to the team:", info.response);

    // Send email to the patient
    transporter.sendMail(mailOptionsPatient, (error, info) => {
      if (error) {
        console.error("Error sending email to patient:", error);
        return res.status(500).send("An error occurred while sending the email to the patient.");
      }
      console.log("Email sent to the patient:", info.response);

      // Save data to the database
      const insertQuery =
        "INSERT INTO contact (contact_Persion_name, contact_Persion_address, contact_Persion_email, contact_Persion_phone, contact_Persion_subject, contact_Persion_message) VALUES (?, ?, ?, ?, ?, ?)";
      const values = [name, address, email, phone, subject, message];

      db.query(insertQuery, values, (dbError, result) => {
        if (dbError) {
          console.error("Error saving data to the database:", dbError);
          return res.status(500).send("An error occurred while saving data to the database.");
        }

        console.log("Data saved to the database:", result);
        res.status(200).send("Emails sent and data saved successfully!");
      });
    });
  });
};

const PatientDetail = (req, res) => {
  const { name, email, phone, message } = req.body;

  // Check for required fields
  if (!name || !email || !phone || !message) {
    return res
      .status(400)
      .json({ error: "Missing required fields in the request." });
  }

  // Configure Nodemailer transporter
  const transporter = nodemailer.createTransport({
    host: "mail.jabalpurivfcentre.com",
    port: 465,
    secure: true,
    auth: {
      user: "support@jabalpurivfcentre.com",
      pass: "JBPivf@321",
    },
  });

  // Email to Team
  const mailOptionsTeam = {
    from: process.env.EMAILSENDER,
    to: "fertilitycenterjbp@gmail.com",
    // to: "shubhsoni1996th@gmail.com",
    subject: "New Patient Inquiry - Jabalpur IVF Center",
    text: `Dear Team,

You have received a new patient inquiry with the following details:

- Name: ${name}
- Email: ${email}
- Phone: ${phone}
- Message: ${message}

Please reach out to the patient as soon as possible.

Best regards,
Jabalpur IVF Center`,
  };

  // Email to Patient
  const mailOptionsPatient = {
    from: process.env.EMAILSENDER,
    to: email,
    subject: "Your Inquiry at Jabalpur IVF Center",
    text: `Dear ${name},

Thank you for reaching out to us at Jabalpur IVF Center. We have successfully received your inquiry with the following details:

Name: ${name}
Email: ${email}
Phone: ${phone}
Message: ${message}

Our team will get back to you shortly.

Best regards,
Jabalpur IVF Center
+91-7770877117
https://jabalpurivfcentre.com`,
  };

  // Send email to the team
  transporter.sendMail(mailOptionsTeam, (error, info) => {
    if (error) {
      console.error("Error sending email to team:", error);
      return res.status(500).send("An error occurred while sending the email to the team.");
    }
    console.log("Email sent to the team:", info.response);

    // Send email to the patient
    transporter.sendMail(mailOptionsPatient, (error, info) => {
      if (error) {
        console.error("Error sending email to patient:", error);
        return res.status(500).send("An error occurred while sending the email to the patient.");
      }
      console.log("Email sent to the patient:", info.response);

      // Save data to the database
      const insertQuery = 
        "INSERT INTO patient_detail (Patient_name, Patient_email, Patient_contact_number, Patient_message) VALUES (?, ?, ?, ?)";
      const values = [name, email, phone, message];

      db.query(insertQuery, values, (dbError, result) => {
        if (dbError) {
          console.error("Error saving data to the database:", dbError);
          return res.status(500).send("An error occurred while saving data to the database.");
        }

        console.log("Data saved to the database:", result);
        res.status(200).send("Emails sent and data saved successfully!");
      });
    });
  });
};

const AdminLogin = (req, res) => {
  const { username, password } = req.body;

  const q = `SELECT * FROM admin WHERE username = ?`;

  db.query(q, [username], (err, data) => {
    if (err) {
      console.error(`Error in username ${err}`);
      return res.status(500).json({ message: "Error in username" });
    }

    if (data.length === 0) {
      console.log("User does not exist!");
      return res.status(401).json({ message: "User does not exist!" });
    }

    // Check if the provided password matches the hashed password stored in the database
    const hashedPassword = data[0].password;
    bcrypt.compare(password, hashedPassword, (err, result) => {
      if (err) {
        console.error("Error comparing passwords:", err);
        return res.status(500).json({ message: "Error comparing passwords" });
      }

      if (!result) {
        console.log("Incorrect password!");
        return res.status(401).json({ message: "Incorrect password!" });
      }

      // Password is correct, user is authenticated
      console.log("Login successful!");
      res.status(200).json({ success: true, message: "Login successful!" });
    });
  });
};

const appointmentGet = (req, res) => {
  // SQL query to select all data from response_data table
  const sql = "SELECT * FROM appointment ORDER BY appointment_Id DESC";

  // Execute the SQL query
  db.query(sql, (err, results) => {
    if (err) {
      console.log(`Error fetching contact data: ${err}`);
      res
        .status(500)
        .json({ success: false, message: "Error fetching contact data" });
    } else {
      // If successful, send the results as JSON response
      res.status(200).json({ success: true, data: results });
    }
  });
};

const booknowGet = (req, res) => {
  // SQL query to select all data from response_data table
  const sql = "SELECT * FROM booknow ORDER BY booking_id DESC";

  // Execute the SQL query
  db.query(sql, (err, results) => {
    if (err) {
      console.log(`Error fetching contact data: ${err}`);
      res
        .status(500)
        .json({ success: false, message: "Error fetching contact data" });
    } else {
      // If successful, send the results as JSON response
      res.status(200).json({ success: true, data: results });
    }
  });
};

const contactGet = (req, res) => {
  // SQL query to select all data from response_data table
  const sql = "SELECT * FROM contact ORDER BY contact_Id DESC";

  // Execute the SQL query
  db.query(sql, (err, results) => {
    if (err) {
      console.log(`Error fetching contact data: ${err}`);
      res
        .status(500)
        .json({ success: false, message: "Error fetching contact data" });
    } else {
      // If successful, send the results as JSON response
      res.status(200).json({ success: true, data: results });
    }
  });
};

const PatientDetailGet = (req, res) => {
  // SQL query to select all data from response_data table
  const sql = "SELECT * FROM patient_detail ORDER BY Patient_Detail_Id DESC";

  // Execute the SQL query
  db.query(sql, (err, results) => {
    if (err) {
      console.log(`Error fetching contact data: ${err}`);
      res
        .status(500)
        .json({ success: false, message: "Error fetching contact data" });
    } else {
      // If successful, send the results as JSON response
      res.status(200).json({ success: true, data: results });
    }
  });
};

module.exports = {
  appointment,
  booknow,
  contact,
  PatientDetail,
  AdminLogin,
  appointmentGet,
  booknowGet,
  contactGet,
  PatientDetailGet,
};
